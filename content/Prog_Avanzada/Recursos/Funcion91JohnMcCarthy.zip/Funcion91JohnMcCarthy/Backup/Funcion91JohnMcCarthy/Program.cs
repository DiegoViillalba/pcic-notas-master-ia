﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Funcion91JohnMcCarthy
{
    public class Program
    {
      public static List<string> myL = new List<string>();

      public static void PrintValues( IEnumerable myCollection )
        {
            Console.Write("            ");
            foreach (Object obj in myCollection)
                Console.Write( "{0}", obj );
            Console.WriteLine();
        }

      public static int mc91( int n )
        {
            int i;
            if (n > 100)
            {
/*                i = n - 10;
                if (Program.myL.Count >= 2)
                {
                    Program.myL.RemoveAt( Program.myL.Count - 1 );
                    Program.myL.RemoveAt( Program.myL.Count - 1 );
                }
                Program.myL.Add( i.ToString() );
                PrintValues( Program.myL ); */
                return n - 10;
            }
            else
            {              
/*                i = n + 11;
                if (Program.myL.Count >= 2)
                {
                    Program.myL.RemoveAt( Program.myL.Count - 1 );
                    Program.myL.RemoveAt( Program.myL.Count - 1 );
                }
                Program.myL.Add( "mc91 " );
                Program.myL.Add( "mc91 " );
                Program.myL.Add( i.ToString() );
                PrintValues( Program.myL );
                while (Console.ReadKey().Key != ConsoleKey.Enter) { } */
                return mc91( mc91( n + 11 ));
            }
        }

        static void Main( string[] args )
        {
            for (int i = -10; i <= 120; i++)
            {   
//                Console.WriteLine( "mc91( " + i + " ) =" );
                Console.WriteLine( "McCarthy91 de " + i + " es " + Program.mc91(i) );
                myL.Clear();
            }
        }
    }
}
